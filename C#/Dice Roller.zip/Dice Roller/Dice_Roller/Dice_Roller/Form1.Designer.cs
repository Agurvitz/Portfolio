﻿namespace Dice_Roller
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblDescription = new System.Windows.Forms.Label();
            this.btnRoll = new System.Windows.Forms.Button();
            this.txtDieNum1 = new System.Windows.Forms.TextBox();
            this.txtDieNum2 = new System.Windows.Forms.TextBox();
            this.txtDieNum3 = new System.Windows.Forms.TextBox();
            this.txtDieNum4 = new System.Windows.Forms.TextBox();
            this.lblD1 = new System.Windows.Forms.Label();
            this.lblD2 = new System.Windows.Forms.Label();
            this.lblD3 = new System.Windows.Forms.Label();
            this.lblD4 = new System.Windows.Forms.Label();
            this.txtDieSides1 = new System.Windows.Forms.TextBox();
            this.txtDieSides2 = new System.Windows.Forms.TextBox();
            this.txtDieSides3 = new System.Windows.Forms.TextBox();
            this.txtDieSides4 = new System.Windows.Forms.TextBox();
            this.lblResults = new System.Windows.Forms.Label();
            this.txtResult1 = new System.Windows.Forms.TextBox();
            this.txtResult2 = new System.Windows.Forms.TextBox();
            this.txtResult3 = new System.Windows.Forms.TextBox();
            this.txtResult4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblDescription
            // 
            this.lblDescription.AutoSize = true;
            this.lblDescription.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescription.Location = new System.Drawing.Point(13, 13);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(362, 40);
            this.lblDescription.TabIndex = 0;
            this.lblDescription.Text = "This program allows you to roll a variety \r\nof dice in different combinations.";
            // 
            // btnRoll
            // 
            this.btnRoll.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRoll.Location = new System.Drawing.Point(42, 230);
            this.btnRoll.Name = "btnRoll";
            this.btnRoll.Size = new System.Drawing.Size(83, 39);
            this.btnRoll.TabIndex = 1;
            this.btnRoll.Text = "Roll";
            this.btnRoll.UseVisualStyleBackColor = true;
            this.btnRoll.Click += new System.EventHandler(this.btnRoll_Click);
            // 
            // txtDieNum1
            // 
            this.txtDieNum1.Location = new System.Drawing.Point(17, 71);
            this.txtDieNum1.Name = "txtDieNum1";
            this.txtDieNum1.Size = new System.Drawing.Size(40, 22);
            this.txtDieNum1.TabIndex = 2;
            this.txtDieNum1.Text = "1";
            // 
            // txtDieNum2
            // 
            this.txtDieNum2.Location = new System.Drawing.Point(17, 108);
            this.txtDieNum2.Name = "txtDieNum2";
            this.txtDieNum2.Size = new System.Drawing.Size(40, 22);
            this.txtDieNum2.TabIndex = 3;
            this.txtDieNum2.Text = "1";
            // 
            // txtDieNum3
            // 
            this.txtDieNum3.Location = new System.Drawing.Point(17, 148);
            this.txtDieNum3.Name = "txtDieNum3";
            this.txtDieNum3.Size = new System.Drawing.Size(40, 22);
            this.txtDieNum3.TabIndex = 4;
            this.txtDieNum3.Text = "1";
            // 
            // txtDieNum4
            // 
            this.txtDieNum4.Location = new System.Drawing.Point(17, 185);
            this.txtDieNum4.Name = "txtDieNum4";
            this.txtDieNum4.Size = new System.Drawing.Size(40, 22);
            this.txtDieNum4.TabIndex = 5;
            this.txtDieNum4.Text = "1";
            // 
            // lblD1
            // 
            this.lblD1.AutoSize = true;
            this.lblD1.Location = new System.Drawing.Point(63, 74);
            this.lblD1.Name = "lblD1";
            this.lblD1.Size = new System.Drawing.Size(16, 17);
            this.lblD1.TabIndex = 6;
            this.lblD1.Text = "d";
            // 
            // lblD2
            // 
            this.lblD2.AutoSize = true;
            this.lblD2.Location = new System.Drawing.Point(63, 111);
            this.lblD2.Name = "lblD2";
            this.lblD2.Size = new System.Drawing.Size(16, 17);
            this.lblD2.TabIndex = 7;
            this.lblD2.Text = "d";
            // 
            // lblD3
            // 
            this.lblD3.AutoSize = true;
            this.lblD3.Location = new System.Drawing.Point(63, 151);
            this.lblD3.Name = "lblD3";
            this.lblD3.Size = new System.Drawing.Size(16, 17);
            this.lblD3.TabIndex = 8;
            this.lblD3.Text = "d";
            // 
            // lblD4
            // 
            this.lblD4.AutoSize = true;
            this.lblD4.Location = new System.Drawing.Point(63, 188);
            this.lblD4.Name = "lblD4";
            this.lblD4.Size = new System.Drawing.Size(16, 17);
            this.lblD4.TabIndex = 9;
            this.lblD4.Text = "d";
            // 
            // txtDieSides1
            // 
            this.txtDieSides1.Location = new System.Drawing.Point(85, 71);
            this.txtDieSides1.Name = "txtDieSides1";
            this.txtDieSides1.Size = new System.Drawing.Size(40, 22);
            this.txtDieSides1.TabIndex = 10;
            this.txtDieSides1.Text = "4";
            // 
            // txtDieSides2
            // 
            this.txtDieSides2.Location = new System.Drawing.Point(85, 108);
            this.txtDieSides2.Name = "txtDieSides2";
            this.txtDieSides2.Size = new System.Drawing.Size(40, 22);
            this.txtDieSides2.TabIndex = 11;
            this.txtDieSides2.Text = "6";
            // 
            // txtDieSides3
            // 
            this.txtDieSides3.Location = new System.Drawing.Point(85, 148);
            this.txtDieSides3.Name = "txtDieSides3";
            this.txtDieSides3.Size = new System.Drawing.Size(40, 22);
            this.txtDieSides3.TabIndex = 12;
            this.txtDieSides3.Text = "8";
            // 
            // txtDieSides4
            // 
            this.txtDieSides4.Location = new System.Drawing.Point(85, 185);
            this.txtDieSides4.Name = "txtDieSides4";
            this.txtDieSides4.Size = new System.Drawing.Size(40, 22);
            this.txtDieSides4.TabIndex = 13;
            this.txtDieSides4.Text = "10";
            // 
            // lblResults
            // 
            this.lblResults.AutoSize = true;
            this.lblResults.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(140, 71);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(86, 20);
            this.lblResults.TabIndex = 14;
            this.lblResults.Text = "Results:";
            // 
            // txtResult1
            // 
            this.txtResult1.Location = new System.Drawing.Point(233, 71);
            this.txtResult1.Name = "txtResult1";
            this.txtResult1.ReadOnly = true;
            this.txtResult1.Size = new System.Drawing.Size(49, 22);
            this.txtResult1.TabIndex = 15;
            // 
            // txtResult2
            // 
            this.txtResult2.Location = new System.Drawing.Point(233, 108);
            this.txtResult2.Name = "txtResult2";
            this.txtResult2.ReadOnly = true;
            this.txtResult2.Size = new System.Drawing.Size(49, 22);
            this.txtResult2.TabIndex = 16;
            // 
            // txtResult3
            // 
            this.txtResult3.Location = new System.Drawing.Point(233, 148);
            this.txtResult3.Name = "txtResult3";
            this.txtResult3.ReadOnly = true;
            this.txtResult3.Size = new System.Drawing.Size(49, 22);
            this.txtResult3.TabIndex = 17;
            // 
            // txtResult4
            // 
            this.txtResult4.Location = new System.Drawing.Point(233, 185);
            this.txtResult4.Name = "txtResult4";
            this.txtResult4.ReadOnly = true;
            this.txtResult4.Size = new System.Drawing.Size(49, 22);
            this.txtResult4.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(382, 284);
            this.Controls.Add(this.txtResult4);
            this.Controls.Add(this.txtResult3);
            this.Controls.Add(this.txtResult2);
            this.Controls.Add(this.txtResult1);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.txtDieSides4);
            this.Controls.Add(this.txtDieSides3);
            this.Controls.Add(this.txtDieSides2);
            this.Controls.Add(this.txtDieSides1);
            this.Controls.Add(this.lblD4);
            this.Controls.Add(this.lblD3);
            this.Controls.Add(this.lblD2);
            this.Controls.Add(this.lblD1);
            this.Controls.Add(this.txtDieNum4);
            this.Controls.Add(this.txtDieNum3);
            this.Controls.Add(this.txtDieNum2);
            this.Controls.Add(this.txtDieNum1);
            this.Controls.Add(this.btnRoll);
            this.Controls.Add(this.lblDescription);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Dice Roller";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Button btnRoll;
        private System.Windows.Forms.TextBox txtDieNum1;
        private System.Windows.Forms.TextBox txtDieNum2;
        private System.Windows.Forms.TextBox txtDieNum3;
        private System.Windows.Forms.TextBox txtDieNum4;
        private System.Windows.Forms.Label lblD1;
        private System.Windows.Forms.Label lblD2;
        private System.Windows.Forms.Label lblD3;
        private System.Windows.Forms.Label lblD4;
        private System.Windows.Forms.TextBox txtDieSides1;
        private System.Windows.Forms.TextBox txtDieSides2;
        private System.Windows.Forms.TextBox txtDieSides3;
        private System.Windows.Forms.TextBox txtDieSides4;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.TextBox txtResult1;
        private System.Windows.Forms.TextBox txtResult2;
        private System.Windows.Forms.TextBox txtResult3;
        private System.Windows.Forms.TextBox txtResult4;
    }
}


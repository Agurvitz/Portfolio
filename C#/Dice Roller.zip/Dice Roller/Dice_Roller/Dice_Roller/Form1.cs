﻿//Aaddison Gurvitz
//November 11th, 2016 ©
//Dice Roller

//This program allows the user to roll four different sets of dice at once

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Roller
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //The Roll button will roll all of the dice by calling the DieRoll function
        //and passing it values. It will then display the results
        private void btnRoll_Click(object sender, EventArgs e)
        {
            //Set the result of each roll based on input by calling DieRoll
            txtResult1.Text = Convert.ToString(DieRoll(Convert.ToInt16(txtDieNum1.Text), 
                Convert.ToInt16(txtDieSides1.Text)));
            txtResult2.Text = Convert.ToString(DieRoll(Convert.ToInt16(txtDieNum2.Text),
                Convert.ToInt16(txtDieSides2.Text)));
            txtResult3.Text = Convert.ToString(DieRoll(Convert.ToInt16(txtDieNum3.Text),
                Convert.ToInt16(txtDieSides3.Text)));
            txtResult4.Text = Convert.ToString(DieRoll(Convert.ToInt16(txtDieNum4.Text),
                Convert.ToInt16(txtDieSides4.Text)));
        }
        //The DieRoll function returns the reuslts of die rolls based on user input
        public int DieRoll(int rollNum, int dieSides)
        {
            if (rollNum <= 0) //Test to determine if there are any dice to be rolled
            {
                return 0; //If not, return 0
            }
            else
            {
                //Initialize variables for the following loop
                int total = 0;
                Random rand = new Random();

                //Roll the dice a number of times based on user input
                for (int num = 0; num < rollNum; num++)
                {
                    //Roll a random number based on input and add it to the total
                    total += rand.Next(1, dieSides);
                }
                return total; //Return the total
            }
        }
    }
}

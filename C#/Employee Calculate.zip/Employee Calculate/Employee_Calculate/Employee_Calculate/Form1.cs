﻿//Aaddison Gurvitz
//November 8th, 2016 ©

//This program extrapolates the yearly salary or hourly wage rate of an employee based on user input

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Calculate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //The explain button gives the user context and frees up screen realestate for other controls
        private void btnExplain_Click(object sender, EventArgs e)
        {
            //Explain to the user how to use the program
            MessageBox.Show("This program calculates an employee's pay or salary based on your input. To start, input the hours worked per week and either an hourly rate or a yearly salary. Input only positive numerical values (do not include punctuation or alphebetical characters). Press the Clear button to empty the fields.");
        }

        //The clear button clears all of the fields
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtSalary.Text = null;
            txtRate.Text = null;
            txtHours.Text = null;
        }

        //The exit button closes the program
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        //The calculate button fills in the rate or salary fields as long as either of them are filled
        //alongside the hours field
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            //If the hours field is empty, have the user fill it
            if (txtHours.Text == null)
            {
                MessageBox.Show("Enter a value for Hours.");
            }
            //Attempt to display salary or hourly rate based on user input
            else
            {
                //Try to display the above calculation. If the user did not input correctly, display
                //an error informing the user again to input the correct information.
                try
                {
                    if (string.IsNullOrEmpty(txtSalary.Text))
                    {
                        txtSalary.Text = Convert.ToString((Convert.ToDouble(txtHours.Text) *
                            Convert.ToDouble(txtRate.Text)) * 52);
                    }
                    else if (string.IsNullOrEmpty(txtRate.Text))
                    {
                        txtRate.Text = Convert.ToString((Convert.ToDouble(txtSalary.Text) / 52)
                            / Convert.ToDouble(txtHours.Text));
                    }
                    //If both fields are filled, tell the user to empty one
                    else
                    {
                        MessageBox.Show("Clear the salary field or the rate field to calculate a value.");
                    }
                }
                catch
                {
                    MessageBox.Show("Something went wrong. Check the fields to make sure that they contain only positive numerical values and try again.");
                }
            }

        }
    }
}

﻿'Aaddison Gurvitz
'October 23, 2016 ©
'This program allows for the rolling of ability scores (or input) and suggestion of a character class
'based on the results

Public Class Main
    'This button explains what the different types of rolls are and how they relate to the ability scores
    Private Sub btnExplain_Click(sender As Object, e As EventArgs) Handles btnExplain.Click
        MessageBox.Show("This program is used to generate the ability scores for characters in Dungeons & Dragons 3rd edition, 5th edition, and in Pathfinder" & vbNewLine & vbNewLine & "The type of roll you use will often be determined by the fiction (or your DM/GM)." & vbNewLine & vbNewLine & "3d6 involves rolling 3 six-sided dice and totaling them. It is often used when a sense of realism or grittiness is needed in a game." & vbNewLine & "4d6d1 is the same as 3d6, but instead you roll an additional die and drop the lowest of the four results. This method will get you characters that are generally above average in ability." & vbNewLine & "2d6+6 involves rolling two dice and adding the result to six. Characters resulting from this method are extremely powerful or special." & vbNewLine & vbNewLine & "If you prefer to roll the dice yourself, you may enter values into each ability score manually.")
    End Sub

    'This button exits the program
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    'This button assesses the ability scores and recommends a class
    Private Sub btnRecommend_Click(sender As Object, e As EventArgs) Handles btnRecommend.Click
        Recommend()
    End Sub

    'This button rolls random numbers from 3 - 18 and assigns them to ability scores
    Private Sub btnRoll3d6_Click(sender As Object, e As EventArgs) Handles btnRoll3d6.Click
        Dim rand As New Random
        txtStrengthScore.Text = Roll3d6()
        txtDexterityScore.Text = Roll3d6()
        txtConstitutionScore.Text = Roll3d6()
        txtIntelligenceScore.Text = Roll3d6()
        txtWisdomScore.Text = Roll3d6()
        txtCharismaScore.Text = Roll3d6()
        'Use the recommend procedure to display classes
        Recommend()
    End Sub

    'This button rolls four random numbers and returns the highest three for each of the ability scores
    Private Sub btnRoll4d6d1_Click(sender As Object, e As EventArgs) Handles btnRoll4d6d1.Click
        txtStrengthScore.Text = Roll4d6d1()
        txtDexterityScore.Text = Roll4d6d1()
        txtConstitutionScore.Text = Roll4d6d1()
        txtIntelligenceScore.Text = Roll4d6d1()
        txtWisdomScore.Text = Roll4d6d1()
        txtCharismaScore.Text = Roll4d6d1()
        'Use the recommend procedure to display classes
        Recommend()
    End Sub

    'This button rolls two random numbers and adds 6 to the result to determine ability scores
    Private Sub btnRoll2d6Plus6_Click(sender As Object, e As EventArgs) Handles btnRoll2d6Plus6.Click
        txtStrengthScore.Text = Roll2d6Plus6()
        txtDexterityScore.Text = Roll2d6Plus6()
        txtConstitutionScore.Text = Roll2d6Plus6()
        txtIntelligenceScore.Text = Roll2d6Plus6()
        txtWisdomScore.Text = Roll2d6Plus6()
        txtCharismaScore.Text = Roll2d6Plus6()
        'Use the recommend procedure to display classes
        Recommend()
    End Sub

    'This button clears all of the ability scores & recommended classes
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtStrengthScore.Text = ""
        txtDexterityScore.Text = ""
        txtConstitutionScore.Text = ""
        txtIntelligenceScore.Text = ""
        txtWisdomScore.Text = ""
        txtCharismaScore.Text = ""
        lblRecommendation.Text = ""
    End Sub

    'This procedure acts as the recommend button and can be used to automatically give options after a roll
    Public Sub Recommend()
        'Clear the text in the recommendation label in case the ability scores have changed
        lblRecommendation.Text = ""
        'Make sure that all values have been entered before calculating
        If String.IsNullOrEmpty(txtStrengthScore.Text) Or String.IsNullOrEmpty(txtDexterityScore.Text) Or String.IsNullOrEmpty(txtConstitutionScore.Text) Or String.IsNullOrEmpty(txtIntelligenceScore.Text) Or String.IsNullOrEmpty(txtWisdomScore.Text) Or String.IsNullOrEmpty(txtCharismaScore.Text) Then
            MessageBox.Show("Enter a value into all ability score fields or press one of the roll buttons to calculate.")
        Else
            'Offer recomendations based on ability scores
            If CInt(txtStrengthScore.Text) >= 14 And CInt(txtConstitutionScore.Text) >= 12 Then
                lblRecommendation.Text += "Barbarian" & vbNewLine
            End If
            If CInt(txtCharismaScore.Text) >= 14 Then
                lblRecommendation.Text += "Bard" & vbNewLine
            End If
            If CInt(txtWisdomScore.Text) >= 14 Then
                lblRecommendation.Text += "Cleric" & vbNewLine
                lblRecommendation.Text += "Druid" & vbNewLine
            End If
            If CInt(txtStrengthScore.Text) >= 14 Or CInt(txtDexterityScore.Text) >= 14 Then
                lblRecommendation.Text += "Fighter" & vbNewLine
            End If
            If CInt(txtDexterityScore.Text) >= 14 And CInt(txtWisdomScore.Text) >= 14 Then
                lblRecommendation.Text += "Monk" & vbNewLine
            End If
            If CInt(txtStrengthScore.Text) >= 14 And CInt(txtCharismaScore.Text) >= 12 Then
                lblRecommendation.Text += "Paladin" & vbNewLine
            End If
            If CInt(txtDexterityScore.Text) >= 14 And CInt(txtWisdomScore.Text) >= 14 Then
                lblRecommendation.Text += "Ranger" & vbNewLine
            End If
            If CInt(txtDexterityScore.Text) >= 14 Then
                lblRecommendation.Text += "Rogue" & vbNewLine
            End If
            If CInt(txtCharismaScore.Text) >= 14 Then
                lblRecommendation.Text += "Sorcerer" & vbNewLine
                lblRecommendation.Text += "Warlock (5e only)" & vbNewLine
            End If
            If CInt(txtIntelligenceScore.Text) >= 14 Then
                lblRecommendation.Text += "Wizard" & vbNewLine
            End If
            'If none of the scores are high enough, jokingly tell the player to roll again
            If CInt(txtStrengthScore.Text) < 14 And CInt(txtDexterityScore.Text) < 14 And CInt(txtWisdomScore.Text) < 14 And CInt(txtWisdomScore.Text) < 14 And CInt(txtIntelligenceScore.Text) < 14 And CInt(txtCharismaScore.Text) < 14 Then
                lblRecommendation.Text += "Innkeeper (Roll again)" & vbNewLine
            End If
        End If
    End Sub

    'This function acts as the 3d6 roll and is called for each score
    Public Function Roll3d6()
        'Generate three random numbers and return their sum
        Dim intTotal As Integer
        intTotal = CInt(Int((6 * Rnd()) + 1)) + CInt(Int((6 * Rnd()) + 1)) + CInt(Int((6 * Rnd()) + 1))
        Return intTotal
    End Function

    'This function acts as the 4d6d1 roll and is called for each score
    Public Function Roll4d6d1()
        Dim intNums(3) As Integer, intTotal As Integer
        'Generate four random numbers, then sort them and return the highest three
        intNums(0) = CInt(Int((6 * Rnd()) + 1))
        intNums(1) = CInt(Int((6 * Rnd()) + 1))
        intNums(2) = CInt(Int((6 * Rnd()) + 1))
        intNums(3) = CInt(Int((6 * Rnd()) + 1))
        Array.Sort(intNums)
        intTotal = intNums(1) + intNums(2) + intNums(3)
        Return intTotal
    End Function

    'This function acts as the 2d6+6 roll and is called for each score
    Public Function Roll2d6Plus6()
        'Generate two random numbers and return their total plus 6
        Dim intTotal As Integer
        intTotal = CInt(Int((6 * Rnd()) + 1)) + CInt(Int((6 * Rnd()) + 1)) + 6
        Return intTotal
    End Function
End Class

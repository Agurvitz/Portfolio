﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.btnClear = New System.Windows.Forms.Button()
        Me.lblRecommendation = New System.Windows.Forms.Label()
        Me.lblRecommendedClasses = New System.Windows.Forms.Label()
        Me.btnRecommend = New System.Windows.Forms.Button()
        Me.txtCharismaScore = New System.Windows.Forms.TextBox()
        Me.lblCharismaScore = New System.Windows.Forms.Label()
        Me.txtWisdomScore = New System.Windows.Forms.TextBox()
        Me.lblWisdomScore = New System.Windows.Forms.Label()
        Me.txtIntelligenceScore = New System.Windows.Forms.TextBox()
        Me.lblIntelligenceScore = New System.Windows.Forms.Label()
        Me.txtConstitutionScore = New System.Windows.Forms.TextBox()
        Me.lblConstitutionScore = New System.Windows.Forms.Label()
        Me.txtDexterityScore = New System.Windows.Forms.TextBox()
        Me.lblDexterityScore = New System.Windows.Forms.Label()
        Me.txtStrengthScore = New System.Windows.Forms.TextBox()
        Me.lblStrengthScore = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnRoll2d6Plus6 = New System.Windows.Forms.Button()
        Me.btnExplain = New System.Windows.Forms.Button()
        Me.btnRoll4d6d1 = New System.Windows.Forms.Button()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.btnRoll3d6 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(12, 287)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(100, 30)
        Me.btnClear.TabIndex = 55
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'lblRecommendation
        '
        Me.lblRecommendation.AutoSize = True
        Me.lblRecommendation.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecommendation.Location = New System.Drawing.Point(283, 142)
        Me.lblRecommendation.Name = "lblRecommendation"
        Me.lblRecommendation.Size = New System.Drawing.Size(0, 13)
        Me.lblRecommendation.TabIndex = 54
        '
        'lblRecommendedClasses
        '
        Me.lblRecommendedClasses.AutoSize = True
        Me.lblRecommendedClasses.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRecommendedClasses.Location = New System.Drawing.Point(283, 95)
        Me.lblRecommendedClasses.Name = "lblRecommendedClasses"
        Me.lblRecommendedClasses.Size = New System.Drawing.Size(144, 36)
        Me.lblRecommendedClasses.TabIndex = 53
        Me.lblRecommendedClasses.Text = "Recommended " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Classes:"
        '
        'btnRecommend
        '
        Me.btnRecommend.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRecommend.Location = New System.Drawing.Point(12, 251)
        Me.btnRecommend.Name = "btnRecommend"
        Me.btnRecommend.Size = New System.Drawing.Size(100, 30)
        Me.btnRecommend.TabIndex = 52
        Me.btnRecommend.Text = "Recommend"
        Me.btnRecommend.UseVisualStyleBackColor = True
        '
        'txtCharismaScore
        '
        Me.txtCharismaScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCharismaScore.Location = New System.Drawing.Point(230, 343)
        Me.txtCharismaScore.Name = "txtCharismaScore"
        Me.txtCharismaScore.Size = New System.Drawing.Size(29, 22)
        Me.txtCharismaScore.TabIndex = 51
        Me.txtCharismaScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCharismaScore
        '
        Me.lblCharismaScore.AutoSize = True
        Me.lblCharismaScore.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCharismaScore.Location = New System.Drawing.Point(174, 322)
        Me.lblCharismaScore.Name = "lblCharismaScore"
        Me.lblCharismaScore.Size = New System.Drawing.Size(85, 18)
        Me.lblCharismaScore.TabIndex = 50
        Me.lblCharismaScore.Text = "Charisma"
        '
        'txtWisdomScore
        '
        Me.txtWisdomScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtWisdomScore.Location = New System.Drawing.Point(230, 297)
        Me.txtWisdomScore.Name = "txtWisdomScore"
        Me.txtWisdomScore.Size = New System.Drawing.Size(29, 22)
        Me.txtWisdomScore.TabIndex = 49
        Me.txtWisdomScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblWisdomScore
        '
        Me.lblWisdomScore.AutoSize = True
        Me.lblWisdomScore.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblWisdomScore.Location = New System.Drawing.Point(186, 276)
        Me.lblWisdomScore.Name = "lblWisdomScore"
        Me.lblWisdomScore.Size = New System.Drawing.Size(73, 18)
        Me.lblWisdomScore.TabIndex = 48
        Me.lblWisdomScore.Text = "Wisdom"
        '
        'txtIntelligenceScore
        '
        Me.txtIntelligenceScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIntelligenceScore.Location = New System.Drawing.Point(230, 251)
        Me.txtIntelligenceScore.Name = "txtIntelligenceScore"
        Me.txtIntelligenceScore.Size = New System.Drawing.Size(29, 22)
        Me.txtIntelligenceScore.TabIndex = 47
        Me.txtIntelligenceScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblIntelligenceScore
        '
        Me.lblIntelligenceScore.AutoSize = True
        Me.lblIntelligenceScore.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIntelligenceScore.Location = New System.Drawing.Point(156, 230)
        Me.lblIntelligenceScore.Name = "lblIntelligenceScore"
        Me.lblIntelligenceScore.Size = New System.Drawing.Size(103, 18)
        Me.lblIntelligenceScore.TabIndex = 46
        Me.lblIntelligenceScore.Text = "Intelligence"
        '
        'txtConstitutionScore
        '
        Me.txtConstitutionScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConstitutionScore.Location = New System.Drawing.Point(230, 205)
        Me.txtConstitutionScore.Name = "txtConstitutionScore"
        Me.txtConstitutionScore.Size = New System.Drawing.Size(29, 22)
        Me.txtConstitutionScore.TabIndex = 45
        Me.txtConstitutionScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblConstitutionScore
        '
        Me.lblConstitutionScore.AutoSize = True
        Me.lblConstitutionScore.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConstitutionScore.Location = New System.Drawing.Point(152, 184)
        Me.lblConstitutionScore.Name = "lblConstitutionScore"
        Me.lblConstitutionScore.Size = New System.Drawing.Size(107, 18)
        Me.lblConstitutionScore.TabIndex = 44
        Me.lblConstitutionScore.Text = "Constitution"
        '
        'txtDexterityScore
        '
        Me.txtDexterityScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDexterityScore.Location = New System.Drawing.Point(230, 159)
        Me.txtDexterityScore.Name = "txtDexterityScore"
        Me.txtDexterityScore.Size = New System.Drawing.Size(29, 22)
        Me.txtDexterityScore.TabIndex = 43
        Me.txtDexterityScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblDexterityScore
        '
        Me.lblDexterityScore.AutoSize = True
        Me.lblDexterityScore.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDexterityScore.Location = New System.Drawing.Point(174, 138)
        Me.lblDexterityScore.Name = "lblDexterityScore"
        Me.lblDexterityScore.Size = New System.Drawing.Size(85, 18)
        Me.lblDexterityScore.TabIndex = 42
        Me.lblDexterityScore.Text = "Dexterity"
        '
        'txtStrengthScore
        '
        Me.txtStrengthScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStrengthScore.Location = New System.Drawing.Point(230, 113)
        Me.txtStrengthScore.Name = "txtStrengthScore"
        Me.txtStrengthScore.Size = New System.Drawing.Size(29, 22)
        Me.txtStrengthScore.TabIndex = 41
        Me.txtStrengthScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblStrengthScore
        '
        Me.lblStrengthScore.AutoSize = True
        Me.lblStrengthScore.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStrengthScore.Location = New System.Drawing.Point(179, 92)
        Me.lblStrengthScore.Name = "lblStrengthScore"
        Me.lblStrengthScore.Size = New System.Drawing.Size(80, 18)
        Me.lblStrengthScore.TabIndex = 40
        Me.lblStrengthScore.Text = "Strength"
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(12, 338)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(100, 30)
        Me.btnExit.TabIndex = 39
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnRoll2d6Plus6
        '
        Me.btnRoll2d6Plus6.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRoll2d6Plus6.Location = New System.Drawing.Point(12, 204)
        Me.btnRoll2d6Plus6.Name = "btnRoll2d6Plus6"
        Me.btnRoll2d6Plus6.Size = New System.Drawing.Size(100, 30)
        Me.btnRoll2d6Plus6.TabIndex = 38
        Me.btnRoll2d6Plus6.Text = "Roll 2d6+6"
        Me.btnRoll2d6Plus6.UseVisualStyleBackColor = True
        '
        'btnExplain
        '
        Me.btnExplain.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExplain.Location = New System.Drawing.Point(12, 86)
        Me.btnExplain.Name = "btnExplain"
        Me.btnExplain.Size = New System.Drawing.Size(100, 30)
        Me.btnExplain.TabIndex = 37
        Me.btnExplain.Text = "Explain"
        Me.btnExplain.UseVisualStyleBackColor = True
        '
        'btnRoll4d6d1
        '
        Me.btnRoll4d6d1.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRoll4d6d1.Location = New System.Drawing.Point(12, 168)
        Me.btnRoll4d6d1.Name = "btnRoll4d6d1"
        Me.btnRoll4d6d1.Size = New System.Drawing.Size(100, 30)
        Me.btnRoll4d6d1.TabIndex = 36
        Me.btnRoll4d6d1.Text = "Roll 4d6d1"
        Me.btnRoll4d6d1.UseVisualStyleBackColor = True
        '
        'lblDescription
        '
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDescription.Location = New System.Drawing.Point(12, 9)
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.Size = New System.Drawing.Size(504, 64)
        Me.lblDescription.TabIndex = 35
        Me.lblDescription.Text = resources.GetString("lblDescription.Text")
        '
        'btnRoll3d6
        '
        Me.btnRoll3d6.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRoll3d6.Location = New System.Drawing.Point(12, 132)
        Me.btnRoll3d6.Name = "btnRoll3d6"
        Me.btnRoll3d6.Size = New System.Drawing.Size(100, 30)
        Me.btnRoll3d6.TabIndex = 34
        Me.btnRoll3d6.Text = "Roll 3d6"
        Me.btnRoll3d6.UseVisualStyleBackColor = True
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(522, 378)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.lblRecommendation)
        Me.Controls.Add(Me.lblRecommendedClasses)
        Me.Controls.Add(Me.btnRecommend)
        Me.Controls.Add(Me.txtCharismaScore)
        Me.Controls.Add(Me.lblCharismaScore)
        Me.Controls.Add(Me.txtWisdomScore)
        Me.Controls.Add(Me.lblWisdomScore)
        Me.Controls.Add(Me.txtIntelligenceScore)
        Me.Controls.Add(Me.lblIntelligenceScore)
        Me.Controls.Add(Me.txtConstitutionScore)
        Me.Controls.Add(Me.lblConstitutionScore)
        Me.Controls.Add(Me.txtDexterityScore)
        Me.Controls.Add(Me.lblDexterityScore)
        Me.Controls.Add(Me.txtStrengthScore)
        Me.Controls.Add(Me.lblStrengthScore)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnRoll2d6Plus6)
        Me.Controls.Add(Me.btnExplain)
        Me.Controls.Add(Me.btnRoll4d6d1)
        Me.Controls.Add(Me.lblDescription)
        Me.Controls.Add(Me.btnRoll3d6)
        Me.Name = "Main"
        Me.Text = "Class Recommender"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnClear As Button
    Friend WithEvents lblRecommendation As Label
    Friend WithEvents lblRecommendedClasses As Label
    Friend WithEvents btnRecommend As Button
    Friend WithEvents txtCharismaScore As TextBox
    Friend WithEvents lblCharismaScore As Label
    Friend WithEvents txtWisdomScore As TextBox
    Friend WithEvents lblWisdomScore As Label
    Friend WithEvents txtIntelligenceScore As TextBox
    Friend WithEvents lblIntelligenceScore As Label
    Friend WithEvents txtConstitutionScore As TextBox
    Friend WithEvents lblConstitutionScore As Label
    Friend WithEvents txtDexterityScore As TextBox
    Friend WithEvents lblDexterityScore As Label
    Friend WithEvents txtStrengthScore As TextBox
    Friend WithEvents lblStrengthScore As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnRoll2d6Plus6 As Button
    Friend WithEvents btnExplain As Button
    Friend WithEvents btnRoll4d6d1 As Button
    Friend WithEvents lblDescription As Label
    Friend WithEvents btnRoll3d6 As Button
End Class
